import React from 'react';
import '../scss/App.scss';
import HTTP from "../common/http";
import Toolbar from './Toolbar';


class App extends React.Component {

  state = {
    from: "2019-08-31",
    to: "2019-09-21",
    browsers: "",
    operatingSystems: "",
    platform: "",
    groupBy: "day",
    initialQueries: false
  }

  constructor(){
    super();
    this.startInitialQueries();
  }

  componentDidMount(){
  }

  changeDate = (label, date) => {
    if (label === "From"){
      this.setState(() => {
        return {from: date};
      });
    } else {
      this.setState(() => {
        return {to: date};
      });
    }
  }

  changeBrowsers = (value) => {

    this.setState(() => ({
      browsers: value.join(",")
    }));
  }

  changeOperatingSystems = (value) => {
    this.setState(() => ({
      operatingSystems: value.join(",")
    }));
  }

  changePlatform = (value) => {
    this.setState(() => ({platform: value}));
  }

  changeGroupBy = (value) => {
    this.setState(() => ({groupBy: value}));
  }

  startInitialQueries = async () => {
    let browsersResponse = await HTTP.get("/api/v1/browsers").then(data => data.data);
    let platformsResponse = await HTTP.get("/api/v1/platforms").then(data => data.data);
    let OSResponse = await HTTP.get("/api/v1/operating-systems").then(data => data.data);
    let groupsResponse = await HTTP.get("/api/v1/groups").then(data => data.data);

    this.setState(() => ({initialQueries: {
      browsers: browsersResponse,
      platforms: platformsResponse,
      os: OSResponse,
      groups: groupsResponse
    }}));
  }

  submit = () => {
    console.log(this.state)
  }

  render(){
    return (
      <div className="main">
        <h1>Statistics App</h1>
        <div className="panel">
        <Toolbar 
          changeDate={this.changeDate}
          changeBrowsers={this.changeBrowsers}
          changeOperatingSystems={this.changeOperatingSystems}
          changePlatform={this.changePlatform}
          changeGroupBy={this.changeGroupBy}
          platform={this.state.platform}
          groupBy={this.state.groupBy}
          initialQueries={this.state.initialQueries}
          submit={this.submit}
          />
          <button className="submit-button" onClick={this.submit}>hfhfhfhf</button>
        </div>
      </div>
    )
  }
}

export default App;
